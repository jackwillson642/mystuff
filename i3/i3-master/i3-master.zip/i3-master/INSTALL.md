### [i3](https://i3wm.org/)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/i3/archive/master.zip) option.

#### Activating the theme

Append the colour palettes in `.config` to your existing i3 configuration files.